$(document).ready(function () {
    function getPersonale(){
        $.get('personale', function(res){
            for(let i = 0; i < res.object.length; i++){
                
                $(` <tr>
                        <td>${res.object[i].nome}</td>
                        <td>${res.object[i].cognome}</td>
                        <td>${res.object[i].ddn}</td>
                        <td>${res.object[i].stipendio}€</td>
                        <td>${res.object[i].dataAssunzione}</td>
                        <td>${res.object[i].idAzienda}</td> 
                        <td>${res.object[i].idRuolo}</td>
                        <td>
                            <button class='btn-modifica-personale' data-id='${res.object[i].id}'>Modifica</button>
                            <button class='btn-elimina-personale' data-id='${res.object[i].id}'>&times;</button>
                        </td>
                    </tr>`).hide().appendTo($('#lista-personale')).fadeIn(i*500);
            }
            // FARSI RESTITUIRE IL NOME DELL'AZIENDA E IL RUOLO TRAMITE L'ID
        })
    }

    getPersonale();

    // AGGIUNGI DIPENDENTI =====================================
    $('#btn-aggiungi-personale').click(function(){
        console.log('aggiungi');

        const nome = $('#nome-dipendente').val();
        const cognome = $('#cognome-dipendente').val();
        const ddn = $('#ddn-dipendente').val();
        const stipendio = +$('#stipendio-dipendente').val();
        const ddAssunzione = $('#dd-assunzione-dipendente').val();
        const idAzienda = +$('#azienda-dipendente').val();
        const idRuolo = +$('#ruolo-dipendente').val();

        
        const dipendente = {nome, cognome, ddn, stipendio, ddAssunzione, idAzienda, idRuolo};

        console.log(dipendente);

        aggiungiPersonale(dipendente);

        $('#nome-dipendente').val('');
        $('#cognome-dipendente').val('');
        $('#ddn-dipendente').val('');
        $('#stipendio-dipendente').val('');
        $('#dd-assunzione-dipendente').val('');
        $('#azienda-dipendente').val('');
        $('#ruolo-dipendente').val('');
    })

    function aggiungiPersonale(dipendente){
        /*
        $.ajax({
            // AGGIUNGERE CONTROLLI ++++++++++++++++++++++++++++++++++++++++++++++++++++
            contentType: "application/json;charset=utf-8",
			url: 'personale',
			type: 'POST',
			data: JSON.stringify(dipendente),
			success: function(res) {
                $('#lista-personale').html('');
                getPersonale();
			}
		}) */
    }

    // MODIFICA DIPENDENTI =====================================
    $('#lista-personale').on('click', '.btn-modifica-personale', function() {
        modificaPersonale(+$(this).attr('data-id'));
    })

    function modificaPersonale(id){
        console.log('modificaPersonale ' + id);
    }


    // ELIMINA DIPENDENTI ======================================
    $('#lista-personale').on('click', '.btn-elimina-personale', function() {
        eliminaPersonale(+$(this).attr('data-id'));
    })

    function eliminaPersonale(id){
        console.log(id);
        $.ajax({
			url: `personale/${id}`,
			type: 'DELETE',
			success: function(res) {
				if (res == true) { /////////////////////
					$('#lista-personale').html('');
					getPersonale();
				} else {
					alert('Qualcosa è andato storto');
				}
			}
		})
    }

    // GESTIONE RUOLI e AZIENDE ================================
    $('#open-aggiungi-personale').click(function(){
        getRuoli();
        // getAziende(); // GET AZIENDE PER LA VISUALIZZAZIONE NELLA SELECT QUANDO SI APRE IL MODALE PER L'AGGIUNTA
    })

    function getRuoli(){
        console.log('Get Ruolo');
        
    }

    // function getAziende(){}

    // GESTIONE MODALE =========================================
    var modal = document.getElementById("modale-aggiungi-personale");
    var btn = document.getElementById("open-aggiungi-personale");
    var span = document.getElementsByClassName("close")[0];

    btn.onclick = function () {
        modal.style.display = "block";
    };

    span.onclick = function () {
        modal.style.display = "none";
    };

    window.onclick = function (event) {
        if (event.target == modal) {
        modal.style.display = "none";
        }
    };
});
