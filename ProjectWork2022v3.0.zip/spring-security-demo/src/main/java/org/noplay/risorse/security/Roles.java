package org.noplay.risorse.security;

public interface Roles {
	static String ADMIN = "ADMIN";
	static String USER = "USER";
}
