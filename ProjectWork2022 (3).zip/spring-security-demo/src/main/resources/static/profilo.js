$(document).ready(function (){
    $.get('secured', function(res) {
        console.log(res.username);
        $(` <span class="lead">Username: </span><span id="username-user">${res.username}</span><br>
            <span class="lead">E-mail: </span><span id="email">${res.email}</span><br>
            <span class="lead">Ruolo: </span><span id="ruolo">${res.ruolo}</span><br>`).appendTo($('#dati-user'));
    });
})