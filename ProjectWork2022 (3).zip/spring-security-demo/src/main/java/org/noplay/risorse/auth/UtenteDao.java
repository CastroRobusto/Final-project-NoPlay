package org.noplay.risorse.auth;

import org.noplay.risorse.util.BasicDao;
import org.springframework.beans.factory.annotation.Value;

public class UtenteDao extends BasicDao  {

	public UtenteDao(@Value("${spring.datasource.url}") String dbAddress, 
			@Value("${spring.datasource.username}") String user, 
			@Value("${spring.datasource.password}") String password) {
		super(dbAddress, user, password);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
